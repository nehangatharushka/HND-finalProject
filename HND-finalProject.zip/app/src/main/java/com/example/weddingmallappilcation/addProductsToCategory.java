package com.example.weddingmallappilcation;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class addProductsToCategory extends AppCompatActivity {

    private String categoryName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }
}