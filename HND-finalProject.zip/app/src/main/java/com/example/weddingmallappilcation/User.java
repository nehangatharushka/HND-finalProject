package com.example.weddingmallappilcation;

public class User {

    public String firstname,lastname,age,email,password;


    public User(){

    }

    public User(String firstname, String lastname, String age, String email, String password){
        this.firstname=firstname;
        this.lastname=lastname;
        this.age=age;
        this.email=email;
        this.password=password;
    }



}
